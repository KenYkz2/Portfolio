#caracteres_interdits=['A','Z','E','R','T','Y','U','I','O','P','Q','S','D','F','G','H','J','K','L','M','W','X','C','V','B','N',',','?',';','.',':','/','!','§','ù','%','*','µ','¨','$','&','é','(','-','è','_','ç','à',')','=','~','#','{','[','|',]
def palindrome(mot):
    if mot.find("'A','Z','E','R','T','Y','U','I','O','P','Q','S','D','F','G','H','J','K','L','M','W','X','C','V','B','N',',','?',';','.',':','/','!','§','ù','%','*','µ','¨','$','&','é','(','-','è','_','ç','à',')','=','~','#','{','[','|',"):
        "print("caracteres invalides")
    elif mot==mot[::-1]:
        print("le mot 'mot' est un  palindrome")
    else:
        print("le mot 'mot' n'est pas n palindrome")
    return("mot")

